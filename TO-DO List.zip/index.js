const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));

let students = [
    { userId: 1, name: 'John Doe', email: 'john@example.com', phone: '1234567890', password: 'password' },
    { userId: 2, name: 'Jane Doe', email: 'jane@example.com', phone: '0987654321', password: 'password' }
];

app.set('view engine', 'ejs');

// Route to render the form
app.get('/', (req, res) => {
    res.render('form', { student: students });
});

// Route to handle form submission
app.post('/insertData', (req, res) => {
    const { name, email, phone, password } = req.body;
    const userId = students.length ? students[students.length - 1].userId + 1 : 1;
    students.push({ userId, name, email, phone, password });
    res.redirect('/');
});

// Route to handle data editing
app.post('/editData/:userId', (req, res) => {
    const { userId } = req.params;
    const { name, email, phone, password } = req.body;
    const index = students.findIndex(student => student.userId == userId);
    if (index !== -1) {
        students[index] = { userId: parseInt(userId), name, email, phone, password };
    }
    res.redirect('/');
});

// Route to handle data deletion
app.post('/deleteData/:userId', (req, res) => {
    const { userId } = req.params;
    students = students.filter(student => student.userId != userId);
    res.redirect('/');
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
